# East-blue
Lets go explore the world! 
ARLONG IS DEFEATED 
